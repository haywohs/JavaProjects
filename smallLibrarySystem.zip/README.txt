LIBRARY APPLICATION

  The program searches through a dataset of available books and either display
  the results by title, by type, or by random or checkout the book if available
  using the ISBN of the book.

DATE
  Feb 10, 2022

AUTHORS
  Yu-Yun Hsieh
  Debora Kwon
  Marcus Lau

HOW TO RUN THE PROGRAM
  Double click on the D.KwonM.LauY.Hsieh.Jar file

